document.addEventListener("DOMContentLoaded", () => {
    setupPage();
});
